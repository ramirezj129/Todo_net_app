using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Test_app.Models;

namespace Test_app.Pages.Test_Td
{
    public class CreateModel : PageModel
    {
        private readonly ApplicationDbContext _db;

        public CreateModel(ApplicationDbContext db)
        {
            _db = db;
        }
    
        public void OnGet()
        {

        }
        [BindProperty]
        public Todo Todo { get; set; }

        public async Task<IActionResult> OnPost()
        {
          if (ModelState.IsValid)
            {
                await _db.Todos.AddAsync(Todo);
                await _db.SaveChangesAsync();
                return Redirect("Tab");

            }
            else
            {
                return Page();
            }

        }

    } 
}  
