using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Test_app.Models;

namespace Test_app.Pages.Test_Td
{
    public class EditModel : PageModel
    {
        private readonly ApplicationDbContext _db;
        public EditModel(ApplicationDbContext db)
        {
            _db = db;
        }
        [BindProperty]
        public Todo Todo { get; set; }

        public async Task OnGet(int id)
        {
            Todo = await _db.Todos.FindAsync(id);
        }
        public async Task<IActionResult> OnPost()
        {
           if (ModelState.IsValid)
            {
                var EditTodo = await _db.Todos.FindAsync(Todo.Id);
                EditTodo.Name = Todo.Name;
                EditTodo.Priority = Todo.Priority;
                EditTodo.IsDone= Todo.IsDone;
                EditTodo.DueDate = Todo.DueDate;

                await _db.SaveChangesAsync();

                return Redirect("Tab");


            }
            else
            {
                return Page();
            }


        }

    }
}
