using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Test_app.Models;

namespace Test_app.Pages.Test_Td
{
    public class TabModel : PageModel
    {
        private readonly ApplicationDbContext _db;

        public TabModel(ApplicationDbContext db)
        {
            _db = db;
        }
        public IEnumerable<Todo> Todo { get; set; }
        public async Task OnGet()
        {
            Todo = await _db.Todos.ToListAsync();

        }

        public async Task<IActionResult> OnPostDelete(int id)
        {
            var DeleteTodo = await _db.Todos.FindAsync(id);
            if(DeleteTodo != null)
            {
                _db.Todos.Remove(DeleteTodo);
                await _db.SaveChangesAsync();
                return Redirect("Tab");
            }
            else
            {
                return Page();
            }


        }
    }
}
