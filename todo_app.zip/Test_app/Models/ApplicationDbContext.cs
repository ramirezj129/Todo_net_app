﻿using Microsoft.EntityFrameworkCore;

namespace Test_app.Models
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
        {
            
        }

        public DbSet<Todo> Todos { get; set; }
    }
}
