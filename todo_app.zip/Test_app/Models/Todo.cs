﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Test_app.Models
{
   
    public class Todo
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string? Name { get; set; }
        [RegularExpression("Low|Medium|High", ErrorMessage = "Enter priority Low, Medium, High, or Leave Empty")]
        public string? Priority { get; set; }
        [DisplayName("Completed")]
        public bool IsDone { get; set; }
        [DisplayName("Due Date")]
        public DateTime DueDate { get; set; }

    }
}
